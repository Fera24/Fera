#include<reg51.h>
void lcd_data(char[]);
void lcd_ok(bit);
void delay(unsigned int);
void delay1(unsigned int);
void lcd_code(char);
void check();
void lcd_init();
sbit rs = P2^0;
sbit rw = P2^1;
sbit en = P2^2;
sbit busy = P1^7;
sbit mot1 = P2^3;
sbit mot2 = P2^4;
sbit door1 = P2^5;
sbit door2 = P2^6;
sbit buzz = P2^7;
#define lcd_port P1 
main()
{
	char index1;
	char stations[][16] = {{"Indrapuri0"}, {"M P Nagar0"}, {"1O NO. Market0"}, {"Sahapura0"}, {"Chuna Bhatti0"}};
	mot1 = 0;
	mot2 = 0;
	buzz = 1;
	door1 = 1;
	door2 = 1;
	lcd_init();
	lcd_code(0x01);
	lcd_data("   Welcome To    0");
	lcd_code(0xC0);
	lcd_data("**Bhopal Metro**0"); 
	delay1(2000);
	lcd_code(0x80);
	for(index1 = 0; index1 != 5; index1++)
	{
		lcd_code(0x01);
		lcd_code(0x80);
		lcd_data("Current Station:0");
		lcd_code(0xC0);
		lcd_data(stations[index1]);
		delay1(200);
		buzz = 0;
		delay1(250);
		buzz = 1;
		//------------------------------Door Open
		door1 = 0;
		delay1(300);
		door1 = 1;
		//------------------------------Door Open
		delay1(300);
		//------------------------------Door Close
		door2 = 0;
		delay1(1000);
		door2 = 1;
		//------------------------------Door Close
		delay1(300);
		mot1 = 1;
		mot2 = 0;
		if(index1 < 4)
		{
			delay1(2000);
			lcd_code(0x01);
			lcd_code(0x80);
			lcd_data("Next Station:0");
			lcd_code(0xC0);
			lcd_data(stations[index1+1]);
			delay1(2000);
			mot1 = 0;
			mot2 = 0;
			lcd_code(0x01);
		}
		else
		{
			lcd_code(0x01);
			lcd_data("End Of Line0");
			delay1(1000);
		}	
	}
 }

void lcd_data(char ch[])
{
	int index1;
	for(index1 = 0; ch[index1] != '0'; index1++)
	{
		check();
		lcd_port = ch[index1];
		lcd_ok(1);
	}	
	return;
}

void lcd_ok(bit mybit)
{
	if(mybit)
	{
		rs = 1;
	}
	else
	{
		rs = 0;
	}
	rw = 0;
	en = 1;
	delay(1);
	en = 0;
	return;
}

void delay1(unsigned int itime)
{
	unsigned int i,j;
	for(i = 0; i < itime; i++)
		for(j = 0; j < 500; j++);
		return;
	   
}

void delay(unsigned int time)
{
	int i = 0;
	for(; time > 0; time--)
		for(; i < 353; i++);
	return;
}

void lcd_init()
{
	lcd_code(0x38);
	lcd_code(0x0C);
	lcd_code(0x01);
	lcd_code(0x06);
	return;
}






void lcd_code(char ch)
{	
	check();		 
	lcd_port = ch;
	lcd_ok(0);
	return; 
}

void check()
{
	rs = 0;
	rw = 1;
	while(busy == 1)
	{
		en = 0;
		delay(1);
		en = 1;
	}
	return;
}

